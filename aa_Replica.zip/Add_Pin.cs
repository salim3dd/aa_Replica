﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Add_Pin : MonoBehaviour
{

    public GameObject pin;
    void Start()
    {
        
    }

   
    void Update()
    {
        if (Input.GetMouseButtonDown(0)) {
            Instantiate(pin, transform.position, transform.rotation);
        }
    }
}
