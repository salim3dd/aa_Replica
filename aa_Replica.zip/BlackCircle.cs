﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlackCircle : MonoBehaviour
{
    public float Speed = 100f;
    void Start()
    {
        
    }
   
    void Update()
    {
        transform.Rotate(0f, 0f, Speed * Time.deltaTime);
    }
}
