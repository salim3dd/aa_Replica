﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class GameControl : MonoBehaviour
{

    public Text TextScore;
    public static int Score;

    public Add_Pin class_addPin;
    public BlackCircle class_BlackCricle;

    public GameObject PanelGameOver;
    public Camera cam;
    void Start()
    {
        Score = 0;
        PanelGameOver.SetActive(false);
        cam.backgroundColor = new Color32(200, 200, 200,255);
    }
   
    void Update()
    {
        TextScore.text = Score.ToString(); 
    }

    public void GameEnd() {

        class_addPin.enabled = false;
        class_BlackCricle.enabled = false;
        PanelGameOver.SetActive(true);
        cam.backgroundColor = new Color32(179, 0, 71, 255);
    }

    public void BTNReset() {

        Time.timeScale = 1;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    
    }
}
