﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pin : MonoBehaviour
{
    public float Speed = 25f;
    bool isPinMoveUp = false;
    public Rigidbody2D rb;
    void Start()
    {
        
    }   
    void Update()
    {
        if (!isPinMoveUp) {
            rb.MovePosition(rb.position + Vector2.up * Speed * Time.deltaTime);
        }

    }

    void OnTriggerEnter2D(Collider2D col) {
        
        if (col.tag == "BlackCircle") {
            transform.SetParent(col.transform);
            isPinMoveUp = true;
            GameControl.Score++;
        }

        if (col.tag == "Pin")
        {
            Time.timeScale = 0;
            FindObjectOfType<GameControl>().GameEnd();
        }

    }
}
